import { useEffect } from "react";
import { AirlineLogo } from "@/components/media/AirlineLogo";
import { SmartImage } from "@/components/media/SmartImage";
import { hotelQuery } from "@/lib/categoryImagery";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { Plane, Hotel, Sparkles, RefreshCw } from "lucide-react";
import { useLiveQuote, type LiveQuote } from "@/hooks/useLiveQuote";
import { PriceSourceBadge } from "@/components/PriceSourceBadge";

type Props = {
  tripId?: string;
  origin?: string;
  destination?: string;
  depart?: string;
  return_date?: string;
  nights: number;
  travelers: number;
  fallbackMxn: number;
};

const fmtMXN = (n: number) =>
  `$${Math.round(n).toLocaleString("es-MX")} MXN`;

export function LiveTripQuote({ tripId, origin, destination, depart, return_date, nights, travelers, fallbackMxn }: Props) {
  const { data, loading, error, refresh, refreshing } = useLiveQuote({
    tripId, origin, destination, depart, return_date, nights, travelers, enabled: true,
  });

  const display = useMotionValue(0);
  const rounded = useTransform(display, (v) => fmtMXN(v));

  useEffect(() => {
    const target = data?.total_mxn ?? (error ? fallbackMxn : 0);
    if (!target) return;
    const controls = animate(display, target, { duration: 1.6, ease: "easeOut" });
    return controls.stop;
  }, [data, error, fallbackMxn, display]);

  if (loading) {
    return (
      <div className="glass-card rounded-2xl p-5 sm:p-8 md:p-10 mb-8 relative overflow-hidden max-w-full">
        <p className="text-xs tracking-[0.2em] uppercase text-primary mb-3">Inversión total estimada</p>
        <div className="h-16 md:h-20 w-2/3 rounded-lg bg-gradient-to-r from-primary/10 via-primary/30 to-primary/10 animate-pulse mb-4" />
        <p className="text-sm text-muted-foreground flex items-center gap-2">
          <RefreshCw className="w-3.5 h-3.5 animate-spin text-primary" />
          Cotizando tarifas y disponibilidad en tiempo real…
        </p>
      </div>
    );
  }

  const q: LiveQuote | null = data;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-5 sm:p-8 md:p-10 mb-8 max-w-full overflow-hidden"
    >
      <div className="flex flex-col items-start justify-between gap-2 mb-3 sm:flex-row sm:gap-4">
        <p className="text-xs tracking-[0.2em] uppercase text-primary">
          {q && (!q.flight || !q.hotel)
            ? `Cotización parcial (${!q.flight ? "sin vuelo" : "sin hotel"}) · grupo de ${travelers} ${travelers === 1 ? "persona" : "personas"}`
            : `Inversión total · grupo de ${travelers} ${travelers === 1 ? "persona" : "personas"}`}
        </p>
        {/* Sin fuente declarada no se asume "en vivo"; el servidor marca OBSOLETO un precio guardado. */}
        {q && <PriceSourceBadge source={q.source} estado={q.estado_dato} consultadoAt={q.fetched_at} />}
      </div>
      <motion.p className="font-display text-4xl sm:text-5xl md:text-6xl gold-text mb-2 break-words leading-tight">
        {rounded as any}
      </motion.p>
      {q && (
        <p className="text-xs text-muted-foreground mb-2">
          ≈ ${q.total_usd.toLocaleString("en-US")} USD · sin extras ni buffer automático
        </p>
      )}
      <p className="text-sm text-muted-foreground mb-1">
        Para <span className="text-foreground font-medium">{travelers} {travelers === 1 ? "persona" : "personas"}</span> · {nights} noches
      </p>
      <p className="text-[11px] text-muted-foreground/80 mb-6 italic">
        Precio total del grupo (no por persona) · ≈ {fmtMXN(Math.round((data?.total_mxn ?? fallbackMxn) / Math.max(1, travelers)))} por persona
      </p>


      {q && (
        <div className="grid md:grid-cols-2 gap-3">
          {q.flight && (
            <div className="rounded-xl border border-border bg-surface/50 p-4">
              <div className="flex items-center gap-2 text-[10px] tracking-widest uppercase text-primary/80 mb-2">
                <Plane className="w-3 h-3" /> Vuelo round-trip
              </div>
              <div className="flex min-w-0 items-center gap-3">
                <AirlineLogo airline={q.flight.airline} logoUrl={q.flight.airline_logo} size={36} shape="square" />
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{q.flight.airline}</p>
                  <p className="text-xs text-muted-foreground">
                    {q.flight.departure} → {q.flight.arrival} · {q.flight.duration} · {q.flight.stops === 0 ? "directo" : `${q.flight.stops} escala${q.flight.stops > 1 ? "s" : ""}`}
                  </p>
                </div>
                <p className="ml-auto shrink-0 font-display text-base sm:text-lg gold-text">${q.flight.price_usd.toLocaleString("en-US")}</p>
              </div>
            </div>
          )}
          {q.hotel && (
            <div className="rounded-xl border border-border bg-surface/50 p-4">
              <div className="flex items-center gap-2 text-[10px] tracking-widest uppercase text-primary/80 mb-2">
                <Hotel className="w-3 h-3" /> Hospedaje {q.hotel.hotel_class ? `${q.hotel.hotel_class}★` : "premium"}
              </div>
              <div className="flex min-w-0 items-center gap-3">
                {/* Miniatura de Google Hotels; si no viene, la foto real del hotel por su nombre (o ilustrativa marcada). */}
                <SmartImage alt={q.hotel.name} imageUrl={q.hotel.thumbnail ?? null} lookup={{ name: q.hotel.name, city: destination ?? null }}
                  stockQuery={hotelQuery(null)} size="thumb" icon={Hotel} className="w-14 h-14 rounded-lg shrink-0" captionPosition="bottom-left" />
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{q.hotel.name}</p>
                  <p className="text-xs text-muted-foreground">
                    ${q.hotel.nightly_usd.toLocaleString("en-US")}/noche × {nights}n
                    {q.hotel.rating ? ` · ${q.hotel.rating}★` : ""}
                  </p>
                </div>
                <p className="ml-auto shrink-0 font-display text-base sm:text-lg gold-text">${q.breakdown.hotel_total_usd.toLocaleString("en-US")}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {q?.aviso && <p className="text-xs text-amber-500 mt-3">{q.aviso}</p>}

      {q && tripId && (
        <div className="mt-4 flex flex-col gap-1 sm:flex-row sm:items-center sm:gap-3">
          {q.can_refresh ? (
            <button
              type="button"
              onClick={refresh}
              disabled={refreshing}
              className="inline-flex items-center justify-center gap-1.5 rounded-full border border-primary/50 px-4 py-1.5 text-xs font-medium text-primary transition hover:bg-primary/10 disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
              Actualizar precio
            </button>
          ) : null}
          <p className="text-[11px] text-muted-foreground">
            {q.can_refresh
              ? "Consultarlo de nuevo usa una búsqueda en vivo de tu plan."
              : "El precio en vivo de este viaje se actualiza como máximo una vez al día."}
          </p>
        </div>
      )}

      {!q && error && (
        <p className="text-xs text-muted-foreground mt-2">
          {error} Mostrando estimación basada en tus selecciones.
        </p>
      )}
    </motion.div>
  );
}
