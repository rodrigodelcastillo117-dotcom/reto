import { createContext, createElement, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { track } from "@/lib/analytics";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type OnboardingState = {
  user_id: string;
  completed_onboarding: boolean;
  completed_at: string | null;
  current_step: number;
  selected_cards: string[];
  selected_loyalty_airlines: string[];
  selected_loyalty_hotels: string[];
  travel_dna_seed: string | null;
};

/** Estado que ve la app; `provisional` = recordado en este dispositivo, aún sin confirmar con el servidor. */
export type OnboardingStatusValue = OnboardingState & { provisional?: boolean };

const defaults = (uid: string): OnboardingState => ({
  user_id: uid,
  completed_onboarding: false,
  completed_at: null,
  current_step: 1,
  selected_cards: [],
  selected_loyalty_airlines: [],
  selected_loyalty_hotels: [],
  travel_dna_seed: null,
});

// Rendimiento (cierre 2026-10): quien ya terminó el onboarding en este dispositivo no espera la
// consulta a user_onboarding_state para ver su pantalla (en 3G eran ~0.8–1.5 s de spinner en cada
// apertura). Se recuerda SOLO "terminado" (por usuario); la consulta se hace igual en segundo plano
// y, si el servidor dijera otra cosa, la guardia redirige como siempre.
const DONE_KEY = (uid: string) => `iatos_onb_done_v1:${uid}`;
export function cachedOnboardingDone(uid: string): boolean {
  try { return localStorage.getItem(DONE_KEY(uid)) === "1"; } catch { return false; }
}
function rememberOnboardingDone(uid: string, done: boolean) {
  try {
    if (done) localStorage.setItem(DONE_KEY(uid), "1");
    else localStorage.removeItem(DONE_KEY(uid));
  } catch { /* sin almacenamiento: se consulta siempre */ }
}

// El estado vive en un solo proveedor: la guardia de rutas y la pantalla de onboarding tenían
// cada una su copia, y al terminar el onboarding la guardia seguía viendo "incompleto" y
// rebotaba entre /onboarding y /dashboard hasta recargar la página.
function useOnboardingState() {
  const { user } = useAuth();
  const uid = user?.id ?? null;
  const [status, setStatus] = useState<OnboardingStatusValue | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const load = useCallback(async () => {
    if (!uid) {
      setStatus(null);
      setIsLoading(false);
      return;
    }
    if (cachedOnboardingDone(uid)) {
      // Ya lo terminó aquí antes: la pantalla se muestra mientras se confirma con el servidor.
      setStatus((s) => (s?.user_id === uid ? s : { ...defaults(uid), completed_onboarding: true, current_step: 5, provisional: true }));
      setIsLoading(false);
    } else {
      setIsLoading(true);
    }
    const { data, error } = await supabase
      .from("user_onboarding_state")
      .select("*")
      .eq("user_id", uid)
      .maybeSingle();
    // Sin red (o error del servidor) y ya terminado aquí: se queda como está; un fallo pasajero no
    // debe mandar de vuelta al onboarding a quien ya lo hizo.
    if (error && cachedOnboardingDone(uid)) {
      setIsLoading(false);
      return;
    }

    if (!data) {
      // Backfill: if this user already has trips or a travel_profile,
      // they're a pre-existing user — mark onboarding complete.
      const [{ count: tripCount }, { data: tp }] = await Promise.all([
        supabase.from("trips").select("id", { count: "exact", head: true }).eq("user_id", uid),
        supabase.from("travel_profiles").select("user_id").eq("user_id", uid).maybeSingle(),
      ]);
      const isExisting = (tripCount ?? 0) > 0 || !!tp;
      const seed: OnboardingState = {
        ...defaults(uid),
        completed_onboarding: isExisting,
        completed_at: isExisting ? new Date().toISOString() : null,
        current_step: isExisting ? 5 : 1,
      };
      await supabase.from("user_onboarding_state").upsert(seed, { onConflict: "user_id" });
      const { data: fresh } = await supabase
        .from("user_onboarding_state")
        .select("*")
        .eq("user_id", uid)
        .maybeSingle();
      const next = fresh ? ({ ...seed, ...(fresh as any) }) : seed;
      rememberOnboardingDone(uid, !!next.completed_onboarding);
      setStatus(next);
    } else {
      rememberOnboardingDone(uid, !!data.completed_onboarding);
      setStatus({
        ...defaults(uid),
        ...data,
        selected_cards: (data.selected_cards as any) ?? [],
        selected_loyalty_airlines: (data.selected_loyalty_airlines as any) ?? [],
        selected_loyalty_hotels: (data.selected_loyalty_hotels as any) ?? [],
      });
    }
    setIsLoading(false);
  }, [uid]);

  useEffect(() => {
    load();
  }, [load]);


  const markStepComplete = useCallback(
    async (step: number, data: Partial<OnboardingState>) => {
      if (!user) return;
      const patch = { ...data, current_step: Math.max(step + 1, 1) };
      const { data: upd } = await supabase
        .from("user_onboarding_state")
        .update(patch as any)
        .eq("user_id", user.id)
        .select()
        .maybeSingle();
      if (upd) setStatus((s) => (s ? { ...s, ...(upd as any) } : s));
    },
    [user]
  );

  // Devuelve false si no se pudo guardar: así la pantalla avisa y NO navega
  // (navegar sin guardar hacía que el guard regresara al usuario a /onboarding).
  const markOnboardingComplete = useCallback(
    async (finalData: Partial<OnboardingState>): Promise<boolean> => {
      if (!user) return false;
      const patch = {
        ...finalData,
        completed_onboarding: true,
        completed_at: new Date().toISOString(),
        current_step: 5,
      };
      const { data: upd, error } = await supabase
        .from("user_onboarding_state")
        .update(patch as any)
        .eq("user_id", user.id)
        .select()
        .maybeSingle();
      if (error) return false;
      if (upd) setStatus((s) => (s ? { ...s, ...(upd as any) } : s));
      rememberOnboardingDone(user.id, true);
      track("onboarding_completed");
      // Correo de bienvenida (solo al propio usuario, fire-and-forget).
      void supabase.functions.invoke("email-bienvenida", { body: {} }).catch(() => {});
      return true;
    },
    [user]
  );

  // Mientras el estado no sea del usuario actual (recién llegó la sesión y el efecto de carga aún
  // no corre) seguimos "cargando": si no, la guardia montaba la página un instante, la desmontaba
  // al empezar la carga y la volvía a montar, y la página perdía lo que estaba haciendo (N-09).
  const stale = uid !== null && status?.user_id !== uid;
  return { status, isLoading: isLoading || stale, markStepComplete, markOnboardingComplete, reload: load };
}

type OnboardingApi = ReturnType<typeof useOnboardingState>;
const OnboardingContext = createContext<OnboardingApi | null>(null);

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const value = useOnboardingState();
  return createElement(OnboardingContext.Provider, { value }, children);
}

export function useOnboardingStatus(): OnboardingApi {
  const ctx = useContext(OnboardingContext);
  if (!ctx) throw new Error("useOnboardingStatus debe usarse dentro de <OnboardingProvider>");
  return ctx;
}
